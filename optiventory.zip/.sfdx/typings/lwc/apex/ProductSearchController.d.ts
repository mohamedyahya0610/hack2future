declare module "@salesforce/apex/ProductSearchController.searchProducts" {
  export default function searchProducts(param: {searchTerm: any}): Promise<any>;
}
