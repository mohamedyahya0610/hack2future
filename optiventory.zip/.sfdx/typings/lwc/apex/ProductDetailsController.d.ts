declare module "@salesforce/apex/ProductDetailsController.getProductDetails" {
  export default function getProductDetails(param: {productId: any}): Promise<any>;
}
